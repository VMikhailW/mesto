const initialCards = [
    {
      name: 'Lexus IS-250',
      link: 'https://images.unsplash.com/photo-1596287665740-889843df5c32?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'
    },
    {
      name: 'Audi RS',
      link: 'https://images.unsplash.com/photo-1606577924006-27d39b132ae2?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'
    },
    {
      name: 'Honda civic EG',
      link: 'https://images.unsplash.com/photo-1592163964712-9b710489ee54?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=333&q=80'
    },
    {
      name: 'Honda civic Type-R',
      link: 'https://images.unsplash.com/photo-1592797520856-883837ddd186?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'
    },
    {
      name: 'Mercedes-Benz AMG',
      link: 'https://images.unsplash.com/photo-1583573278124-e8d4fd3edf3c?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'
    },
    {
      name: 'BMW M4',
      link: 'https://images.unsplash.com/photo-1598420942196-352027d9c86c?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'
    }
  ];
  

  